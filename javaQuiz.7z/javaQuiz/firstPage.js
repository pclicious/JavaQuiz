function createImgBtn(){
    document.getElementById("nextpagebtn").style.cursor="pointer";
}